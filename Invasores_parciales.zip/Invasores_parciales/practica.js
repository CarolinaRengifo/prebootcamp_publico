var biblioteca = ["Cien Años de Soledad", "Pedro Páramo", "La Casa de los Espíritus"];

biblioteca.push("El Laberinto de la Soledad");

biblioteca[1] = "El Llano en Llamas";

console.log(biblioteca);